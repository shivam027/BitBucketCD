var shell = require('shelljs');
var fs = require('fs');

var private_key = process.env.private_key.replace(/\\n/g, '\n');

var cred = {
    "type" : process.env.type,
    "project_id" : process.env.project_id,
    "private_key_id" : process.env.private_key_id,
    "client_email" : process.env.client_email,
    "client_id" : process.env.client_id,
    "auth_uri" : process.env.auth_uri,
    "token_uri" : process.env.token_uri,
    "auth_provider_x509_cert_url" : process.env.auth_provider_x509_cert_url,
    "client_x509_cert_url": process.env.client_x509_cert_url,
    "private_key" : private_key
}

cred = JSON.stringify(cred);
console.log(cred);

fs.writeFile(`${__dirname}/original_creds.json`, cred, 'utf8', function (err) {
    if (err) {
        console.log("An error occured while writing JSON Object to File.");
        return console.log(err);
    }
 
    console.log("JSON file has been saved.");

    shell.sed('-i', 'project_name', process.env.project_name, `${__dirname}/main.tf`);

    var tf_command = 'cd templates && terraform init -force-copy && ' + 'terraform apply -var Database_name=' + process.env.database_name + ' -auto-approve' ;
    shell.exec(tf_command);

});