
- Use Terraform templates to define Google Cloud SQL resource for our apps.
- Create Octopus release in https://rabbit.octopus.app/app#/Spaces-42/projects/cloud-sql when merged into `latest`.
- Octopus release process should support tenants that need Cloud SQL.
